<?php
// ======== CONEXÃO COM O BANCO ========
$servername = "localhost";
$username = "spfw_user";
$password = "Gui10dav!";
$dbname = "spfw_db";

// Criando a conexão com PDO
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

// ======== PROCESSAMENTO DO FORMULÁRIO ========
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Pega os dados do formulário
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $mensagem = trim($_POST['mensagem']);

    // Verifica se todos os campos foram preenchidos
    if (!empty($nome) && !empty($email) && !empty($mensagem)) {
        try {
            // Prepara e executa a inserção
            $sql = "INSERT INTO contato (nome, email, mensagem) VALUES (:nome, :email, :mensagem)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':mensagem', $mensagem);
            $stmt->execute();

            // Mensagem de sucesso
            echo "<script>alert('Mensagem enviada com sucesso!'); window.location.href='contato.html';</script>";
        } catch (PDOException $e) {
            echo "<script>alert('Erro ao enviar a mensagem.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Por favor, preencha todos os campos.'); window.history.back();</script>";
    }
}

// Fecha a conexão
$conn = null;
?>
