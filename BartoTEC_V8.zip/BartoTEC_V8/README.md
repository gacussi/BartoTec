Membros do grupo:

Guilherme Acussi
Gabriel Miller
João
