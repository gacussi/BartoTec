CREATE DATABASE spfw_bd;

CREATE USER 'gacussi'@'localhost' IDENTIFIED BY 'Gui10dav!2';

GRANT ALL PRIVILEGES ON spfw_bd.* TO 'gacussi'@'localhost';

FLUSH PRIVILEGES;

USE spfw_bd;

CREATE TABLE contatos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    assunto VARCHAR(200),
    mensagem TEXT NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);