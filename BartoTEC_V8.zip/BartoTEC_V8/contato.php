<?php

$servidor = "localhost";
$root = "root";
$senha_bd = "";
$nome_bd = "spfw_db"; 

$conexao = new mysqli($servidor, $root, $senha_bd, $nome_bd);

if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nome = $conexao->real_escape_string($_POST['nome']);
    $email = $conexao->real_escape_string($_POST['email']);
    $assunto = $conexao->real_escape_string($_POST['assunto']);
    $mensagem = $conexao->real_escape_string($_POST['mensagem']);

    $sql = "INSERT INTO contatos (nome, email, assunto, mensagem) VALUES (?, ?, ?, ?)";

    $stmt = $conexao->prepare($sql);

    $stmt->bind_param("ssss", $nome, $email, $assunto, $mensagem);

    if ($stmt->execute()) {
        echo "Mensagem enviada com sucesso! Em breve entraremos em contato.";
    } else {
        echo "Erro ao enviar a mensagem: " . $stmt->error;
    }

    $stmt->close();

} else {
    echo "Método de requisição inválido.";
}

$conexao->close();

?>