<?php

$servername = "localhost";
$username = "spfw_user";
$password = "Gui10dav!";
$dbname = "spfw_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $mensagem = trim($_POST['mensagem']);

    if (!empty($nome) && !empty($email) && !empty($mensagem)) {
        try {
            $sql = "INSERT INTO contato (nome, email, mensagem) VALUES (:nome, :email, :mensagem)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':mensagem', $mensagem);
            $stmt->execute();

            echo "<script>alert('Mensagem enviada com sucesso!'); window.location.href='contato.html';</script>";
        } catch (PDOException $e) {
            echo "<script>alert('Erro ao enviar a mensagem.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Por favor, preencha todos os campos.'); window.history.back();</script>";
    }
}

// Fecha a conexão
$conn = null;
?>
